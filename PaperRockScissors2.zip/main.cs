using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Hey, you. You're finally awake!");

    Console.WriteLine ("What is your name player one?");
      string PlayerOne = Console.ReadLine();

    Console.WriteLine ("Hello " + PlayerOne);

    Console.WriteLine ("And you! You were tring to cross the border, right?");
    Console.WriteLine ("What is your name player two?");

      string PlayerTwo = Console.ReadLine();
    
    Console.WriteLine ("Hi " + PlayerTwo);
    Console.WriteLine ("Before you'll try to walk right into that Imperial ambush, same as us, I'd like to ask.");
    Console.WriteLine ("Are you " + PlayerOne + " and " + PlayerTwo + " fimiliar with Paper, rock or scissors?");
    Console.WriteLine ("The rules are quite simple. Come, let's play!");
    Console.WriteLine (PlayerOne + " choose your weapon first! PAPER, ROCK or SCISSORS?");

      string ChoiceOne = Console.ReadLine();
      Console.Clear();

    Console.WriteLine ("Wise choice, " + PlayerOne + " Now you, " + PlayerTwo + "! What are you going to play against? PAPER, ROCK or SCISSORS?");

      string ChoiceTwo = Console.ReadLine();
      Console.Clear();

if (ChoiceOne == "PAPER" && ChoiceTwo == "ROCK"){
      Console.WriteLine ("Congratulation, " + PlayerOne + " wins! Good luck next time, " + PlayerTwo);
    }
    else {
      if (ChoiceOne == "PAPER" && ChoiceTwo == "PAPER"){
      Console.WriteLine ("It is a tie. Try again and we'll see which one of you is better!!");
      }
      else {
        if (ChoiceOne == "PAPER" && ChoiceTwo == "SCISSORS"){
          Console.WriteLine ("Congrats, " + PlayerTwo + " wins! Don't be sad, " + PlayerOne + ". You still have a chance to win.");
        }
        else{
          if (ChoiceOne == "ROCK" && ChoiceTwo == "ROCK"){
            Console.WriteLine ("Whoa, it's a draw! Like they say: Great minds think alike!");
          }
          else{
            if (ChoiceOne == "ROCK" && ChoiceTwo == "SCISSORS"){
              Console.WriteLine ("Congrats, " + PlayerOne + ", you won this time!");
            }
            else{
              if (ChoiceOne == "ROCK" && ChoiceTwo == "PAPER"){
                Console.WriteLine ("Congratulation, " + PlayerTwo + " wins! Good luck next time, " + PlayerOne);
              }
              else{
                if (ChoiceOne == "SCISSORS" && ChoiceTwo == "PAPER"){
                  Console.WriteLine ("Congratulation, " + PlayerOne + " wins! It'll be better next time, " + PlayerTwo);
                }
                else{
                  if (ChoiceOne == "SCISSORS" && ChoiceTwo == "ROCK"){
                    Console.WriteLine ("Congrats, " + PlayerTwo + " wins! Try next time, " + PlayerOne);
                  }
                  else{
                    if (ChoiceOne == "SCISSORS" && ChoiceTwo == "SCISSORS"){
                      Console.WriteLine ("Hey, if you don't score, you'll play to the end of the world. It's a tie.");
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}