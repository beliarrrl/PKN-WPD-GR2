using System;

class MainClass {
  public static void Main (string[] args) {
    string[] week = {"Moday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
    Console.WriteLine("Hello New Week:");
    for (int i = 0; i < week.Length; i++)
    Console.WriteLine(week[i]);
  }
}