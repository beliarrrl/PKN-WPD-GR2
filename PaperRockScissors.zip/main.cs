using System;

class MainClass {
  public static void Main (string[] args) {
    Console.WriteLine ("Hey, you. You're finally awake!");

    Console.WriteLine ("What is your name player one?");
    string PlayerOne = Console.ReadLine();

    Console.WriteLine ("Hello " + PlayerOne);

    Console.WriteLine ("And you! You were tring to cross the border, right?");
    Console.WriteLine ("What is your name player two?");

    string PlayerTwo = Console.ReadLine();
    
    Console.WriteLine ("Hi " + PlayerTwo);
    Console.WriteLine ("Choose your weapon! Paper, rock or scissors?");
    Console.WriteLine (PlayerOne + "podaj znak - K,P,N");

    string FirstSign = Console.ReadLine();
    
    //Czyszczenie konsoli
    Console.Clear();

    Console.WriteLine ("Now you! What are you going to play againt other player? Paper, rock or scissors?");

    //Console.WriteLine (PlayerTwo + "podaj znak - K,P,N")

    if (FirstSign == "k" && SecondSign == "N"){Console.WritLine("Result")}

      }
}